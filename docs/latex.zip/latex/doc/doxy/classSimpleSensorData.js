var classSimpleSensorData =
[
    [ "SimpleSensorData", "classSimpleSensorData.html#a11e346aae50f95840a5a92824e3fecc1", null ],
    [ "~SimpleSensorData", "classSimpleSensorData.html#a3700727cd38b4754462cbab02d2b202d", null ],
    [ "SimpleSensorData", "classSimpleSensorData.html#a5e99f281acd0b3d053f492a764e57e6d", null ],
    [ "dup", "classSimpleSensorData.html#a3596358623935b76f49335ccc4a3c91d", null ],
    [ "sensorData", "classSimpleSensorData.html#aee32bc9486031b580968610d8aa692ef", null ],
    [ "sizeX", "classSimpleSensorData.html#ae3a383449d35b0afd07db924fc0b64e3", null ],
    [ "sizeY", "classSimpleSensorData.html#a13f60172b2b6b49258eabd4a676e6cc6", null ]
];