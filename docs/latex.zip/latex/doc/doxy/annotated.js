var annotated =
[
    [ "CustomLinearMobility", "classCustomLinearMobility.html", "classCustomLinearMobility" ],
    [ "CustomWorldUtility", "classCustomWorldUtility.html", "classCustomWorldUtility" ],
    [ "ExtendedMessage", "classExtendedMessage.html", "classExtendedMessage" ],
    [ "MyWirelessNode", "classMyWirelessNode.html", "classMyWirelessNode" ],
    [ "NodeType", "classNodeType.html", "classNodeType" ],
    [ "Sensor", "classSensor.html", "classSensor" ],
    [ "SensorType", "structSensorType.html", "structSensorType" ],
    [ "SimpleCoord", "classSimpleCoord.html", "classSimpleCoord" ],
    [ "SimpleSensorData", "classSimpleSensorData.html", "classSimpleSensorData" ],
    [ "SimpleSensorType", "classSimpleSensorType.html", "classSimpleSensorType" ],
    [ "StatisticsInterface", "classStatisticsInterface.html", "classStatisticsInterface" ]
];