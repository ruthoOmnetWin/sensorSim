var classSensor =
[
    [ "Sensor", "classSensor.html#a342d6d11ef572c8cba92cb76fb1a294b", null ],
    [ "~Sensor", "classSensor.html#aee8c70e7ef05ce65e7ee33686b5d7db2", null ],
    [ "activity", "classSensor.html#a55b5db4378432b6386d7081764602b2a", null ],
    [ "finish", "classSensor.html#a56073dd4ca6b1cdbaa62bc07fbf0fa00", null ],
    [ "getSensorData", "classSensor.html#a20d09c2544102747809c72db7b6ea832", null ],
    [ "handleMessage", "classSensor.html#a1f177124922161374841f28f00e3d778", null ],
    [ "initialize", "classSensor.html#a7e8f8d7e9563dd259cdc2d6a599e2666", null ]
];