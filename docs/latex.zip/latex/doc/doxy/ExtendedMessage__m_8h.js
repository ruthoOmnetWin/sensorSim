var ExtendedMessage__m_8h =
[
    [ "ExtendedMessage", "classExtendedMessage.html", "classExtendedMessage" ],
    [ "MSGC_VERSION", "ExtendedMessage__m_8h.html#a77f5ea746b531cbdbc322a93741e33a6", null ],
    [ "doPacking", "ExtendedMessage__m_8h.html#a5f1dbc3f7818e07ebbdcd23bc006ad7f", null ],
    [ "doUnpacking", "ExtendedMessage__m_8h.html#a7edd4e36f3588e0490c0b25fc5caed0d", null ]
];