var searchData=
[
  ['string_2drelated',['String-related',['/home/rutho/BA/omnetpp-4.5//doc/api/group__FunctionsString.html',1,'']]],
  ['simulation_20core_20classes',['Simulation core classes',['/home/rutho/BA/omnetpp-4.5//doc/api/group__SimCore.html',1,'']]],
  ['statistical_20data_20collection',['Statistical data collection',['/home/rutho/BA/omnetpp-4.5//doc/api/group__Statistics.html',1,'']]]
];
