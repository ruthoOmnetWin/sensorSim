var searchData=
[
  ['y',['y',['../classSimpleCoord.html#a10cd9244f71d5694962ef6dcfa419127',1,'SimpleCoord']]]
];
