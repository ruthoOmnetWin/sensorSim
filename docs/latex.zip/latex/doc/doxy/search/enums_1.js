var searchData=
[
  ['type',['Type',['/home/rutho/BA/omnetpp-4.5//doc/api/classcConfigOption.html#af4a1d608a199a5732612d6427aae7f95',1,'cConfigOption::Type()'],['/home/rutho/BA/omnetpp-4.5//doc/api/classcGate.html#ac548a8cc681cf0c39afb2b993fe6e09f',1,'cGate::Type()'],['/home/rutho/BA/omnetpp-4.5//doc/api/classcNEDValue.html#af31583b19ac37e336ce3c0d665117fd6',1,'cNEDValue::Type()']]]
];
