var searchData=
[
  ['enums_2c_20types_2c_20function_20typedefs',['Enums, types, function typedefs',['/home/rutho/BA/omnetpp-4.5//doc/api/group__EnumsTypes.html',1,'']]],
  ['extension_20interfaces',['Extension interfaces',['/home/rutho/BA/omnetpp-4.5//doc/api/group__EnvirExtensions.html',1,'']]]
];
