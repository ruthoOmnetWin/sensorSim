var searchData=
[
  ['msgc_5fversion',['MSGC_VERSION',['../ExtendedMessage__m_8h.html#a77f5ea746b531cbdbc322a93741e33a6',1,'ExtendedMessage_m.h']]]
];
