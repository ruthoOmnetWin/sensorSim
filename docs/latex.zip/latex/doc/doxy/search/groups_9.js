var searchData=
[
  ['user_20interface_3a_20cenvir_20and_20ev',['User interface: cEnvir and ev',['/home/rutho/BA/omnetpp-4.5//doc/api/group__Envir.html',1,'']]],
  ['utility_20classes',['Utility classes',['/home/rutho/BA/omnetpp-4.5//doc/api/group__SimSupport.html',1,'']]]
];
