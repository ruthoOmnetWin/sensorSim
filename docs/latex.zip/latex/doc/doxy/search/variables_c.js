var searchData=
[
  ['sensordata',['sensorData',['../classMyWirelessNode.html#af2717ec4284f325ddc38e7aab334a697',1,'MyWirelessNode::sensorData()'],['../classSimpleSensorData.html#aee32bc9486031b580968610d8aa692ef',1,'SimpleSensorData::sensorData()']]],
  ['sensortype',['sensorType',['../classSimpleSensorType.html#a0ccb4b3b0340fd7e6d9f83a4c8b9b69e',1,'SimpleSensorType']]],
  ['sizex',['sizeX',['../classSimpleSensorData.html#ae3a383449d35b0afd07db924fc0b64e3',1,'SimpleSensorData::sizeX()'],['../classCustomWorldUtility.html#a05f35ec3e94509d81b44e891be8d52e5',1,'CustomWorldUtility::sizeX()']]],
  ['sizey',['sizeY',['../classSimpleSensorData.html#a13f60172b2b6b49258eabd4a676e6cc6',1,'SimpleSensorData::sizeY()'],['../classCustomWorldUtility.html#a9941ba5f5607868671de963e427c019e',1,'CustomWorldUtility::sizeY()']]],
  ['source_5fvar',['source_var',['../classExtendedMessage.html#ad94fa5e715f14f856756f4b76fa7adbf',1,'ExtendedMessage']]]
];
