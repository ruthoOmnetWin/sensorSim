var searchData=
[
  ['objectkind',['ObjectKind',['/home/rutho/BA/omnetpp-4.5//doc/api/classcConfigOption.html#a1aec918182175c547aabb03a9583ab25',1,'cConfigOption']]],
  ['optype',['OpType',['/home/rutho/BA/omnetpp-4.5//doc/api/classcDynamicExpression.html#a9c0e48b0297bf6501285584666679235',1,'cDynamicExpression']]]
];
