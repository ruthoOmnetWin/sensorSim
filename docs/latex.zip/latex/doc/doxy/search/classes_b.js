var searchData=
[
  ['result_5ft',['result_t',['/home/rutho/BA/omnetpp-4.5//doc/api/structcChannel_1_1result__t.html',1,'cChannel']]]
];
