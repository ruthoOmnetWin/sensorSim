var searchData=
[
  ['delay',['delay',['/home/rutho/BA/omnetpp-4.5//doc/api/structcChannel_1_1result__t.html#abfef402a841b2cf15549d3107d60754b',1,'cChannel::result_t']]],
  ['destination_5fvar',['destination_var',['../classExtendedMessage.html#a5500e69efec5761be0282886f730541e',1,'ExtendedMessage']]],
  ['discard',['discard',['/home/rutho/BA/omnetpp-4.5//doc/api/structcChannel_1_1result__t.html#a008a5c54d6a06538fcba7426210900a8',1,'cChannel::result_t']]],
  ['displaystring',['displayString',['/home/rutho/BA/omnetpp-4.5//doc/api/classcPostDisplayStringChangeNotification.html#a9e217e483d24189aac2bacbcba3bbea5',1,'cPostDisplayStringChangeNotification::displayString()'],['/home/rutho/BA/omnetpp-4.5//doc/api/classcPreDisplayStringChangeNotification.html#a2e1ac58f471baf261ff631a3edd5e9de',1,'cPreDisplayStringChangeNotification::displayString()']]],
  ['duration',['duration',['/home/rutho/BA/omnetpp-4.5//doc/api/structcChannel_1_1result__t.html#acb8bc35f3c3e1e4c0d09eef09d4dfd0d',1,'cChannel::result_t']]]
];
