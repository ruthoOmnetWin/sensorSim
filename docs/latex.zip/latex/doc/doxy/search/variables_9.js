var searchData=
[
  ['oldparentmodule',['oldParentModule',['/home/rutho/BA/omnetpp-4.5//doc/api/classcPostModuleReparentNotification.html#a77ae1e5628abe910615089736f496cf5',1,'cPostModuleReparentNotification']]],
  ['oldsize',['oldSize',['/home/rutho/BA/omnetpp-4.5//doc/api/classcPostGateVectorResizeNotification.html#a4f872fb6b4a376e02bd181826d8c7701',1,'cPostGateVectorResizeNotification']]]
];
