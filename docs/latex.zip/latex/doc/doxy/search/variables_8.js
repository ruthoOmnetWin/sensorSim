var searchData=
[
  ['nedfunction',['NEDFunction',['/home/rutho/BA/omnetpp-4.5//doc/api/group__EnumsTypes.html#ga863e3ae302e9cdbe18b4d67d2d9bcdf1',1,]]],
  ['newparentmodule',['newParentModule',['/home/rutho/BA/omnetpp-4.5//doc/api/classcPreModuleReparentNotification.html#adca093dfc679e0acf5c85f942a135160',1,'cPreModuleReparentNotification']]],
  ['newsize',['newSize',['/home/rutho/BA/omnetpp-4.5//doc/api/classcPreGateVectorResizeNotification.html#a3947ac2e74d572edeeebc2334c2c334b',1,'cPreGateVectorResizeNotification']]],
  ['numnodes',['numNodes',['../classCustomWorldUtility.html#a32f28e6a1a08c7c677d1163979956117',1,'CustomWorldUtility']]],
  ['numreceived',['numReceived',['../classStatisticsInterface.html#ab8903c2fc5b9b6e93172a89f37b3f620',1,'StatisticsInterface']]],
  ['numsent',['numSent',['../classStatisticsInterface.html#a42d887601ec32670fd2892b4ef48e91a',1,'StatisticsInterface']]]
];
