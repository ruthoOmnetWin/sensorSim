var searchData=
[
  ['divfunc',['DivFunc',['/home/rutho/BA/omnetpp-4.5//doc/api/group__EnumsTypes.html#gade5c525991f38f272681b30cf390d940',1,'cKSplit::DivFunc()'],['/home/rutho/BA/omnetpp-4.5//doc/api/group__EnumsTypes.html#gade5c525991f38f272681b30cf390d940',1,'DivFunc()(Global Namespace)']]]
];
