var searchData=
[
  ['voiddelfunc',['VoidDelFunc',['/home/rutho/BA/omnetpp-4.5//doc/api/group__EnumsTypes.html#ga4b8f31d53f8936a0c556ceece17a058f',1,]]],
  ['voiddupfunc',['VoidDupFunc',['/home/rutho/BA/omnetpp-4.5//doc/api/group__EnumsTypes.html#ga0f99009fbbd87108d6c0679188d7730a',1,]]]
];
