var searchData=
[
  ['z',['z',['../classSimpleCoord.html#a2d02de11069b84ba78781eb5793f1df6',1,'SimpleCoord']]]
];
