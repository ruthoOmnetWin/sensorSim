var searchData=
[
  ['x',['x',['../classSimpleCoord.html#ad8d88f139da61a0bc30fee4518c01788',1,'SimpleCoord']]]
];
