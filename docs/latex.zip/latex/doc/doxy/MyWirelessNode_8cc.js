var MyWirelessNode_8cc =
[
    [ "Define_Module", "MyWirelessNode_8cc.html#a12377eb18b5b48e726ef81fae508348a", null ],
    [ "Register_Class", "MyWirelessNode_8cc.html#a9be8bf7eaf81d28d850a9956f2bb3572", null ]
];