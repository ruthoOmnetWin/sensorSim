var classExtendedMessage =
[
    [ "ExtendedMessage", "classExtendedMessage.html#ade0274ccdff9560ffe8fad9df854f319", null ],
    [ "ExtendedMessage", "classExtendedMessage.html#a98cc3e001bc44e7f13db49556bbfde09", null ],
    [ "~ExtendedMessage", "classExtendedMessage.html#a910195e5d212e7efbc1289613f61c6ff", null ],
    [ "copy", "classExtendedMessage.html#ab07ff9eccc340341355a0a341bb971fb", null ],
    [ "dup", "classExtendedMessage.html#af3e6533074e0f1804f7d4c1ca2bdccd9", null ],
    [ "getDestination", "classExtendedMessage.html#a996afd43620680ce68c75604babd091b", null ],
    [ "getHopCount", "classExtendedMessage.html#a9b4ec09ba1a5913dd6c3952c09748779", null ],
    [ "getSource", "classExtendedMessage.html#af7eaaeebebdcd783212aa9ff2170f145", null ],
    [ "operator=", "classExtendedMessage.html#ad9aa685b7360efaa3777167677343f51", null ],
    [ "operator==", "classExtendedMessage.html#ad6bf387750a00b6352c7054e58a110d7", null ],
    [ "parsimPack", "classExtendedMessage.html#abad8c6d568cff093239ebcb024034f1e", null ],
    [ "parsimUnpack", "classExtendedMessage.html#aa9d0e2513c59d1dc2e31373b155a2e51", null ],
    [ "setDestination", "classExtendedMessage.html#a813ecbc567b0127c4d57b451b3afb364", null ],
    [ "setHopCount", "classExtendedMessage.html#a71e081f7cdc58d2f55a589757639365c", null ],
    [ "setSource", "classExtendedMessage.html#adccfc56b16455ecc18975b22bc8f9e2b", null ],
    [ "destination_var", "classExtendedMessage.html#a5500e69efec5761be0282886f730541e", null ],
    [ "hopCount_var", "classExtendedMessage.html#a976f580abc29bb900761b567615a7b5f", null ],
    [ "source_var", "classExtendedMessage.html#ad94fa5e715f14f856756f4b76fa7adbf", null ]
];