var classStatisticsInterface =
[
    [ "finish", "classStatisticsInterface.html#a50a7b06a009cc7693e5677f67e1ab23c", null ],
    [ "generateMessage", "classStatisticsInterface.html#a519db68a06bb988bceea9183224033fe", null ],
    [ "updateDisplay", "classStatisticsInterface.html#a72197f87748af10d75ac70caddb2712e", null ],
    [ "hopCountStats", "classStatisticsInterface.html#a14368dced736b91c2b3208308175c946", null ],
    [ "hopCountVector", "classStatisticsInterface.html#a8cfabbb0aa6c933032214ac7b117d225", null ],
    [ "numReceived", "classStatisticsInterface.html#ab8903c2fc5b9b6e93172a89f37b3f620", null ],
    [ "numSent", "classStatisticsInterface.html#a42d887601ec32670fd2892b4ef48e91a", null ]
];