var classCustomLinearMobility =
[
    [ "CustomLinearMobility", "classCustomLinearMobility.html#ac43877db013db3bcb63350597be303f8", null ],
    [ "getCurrentPosition", "classCustomLinearMobility.html#a41fef75955bbfaea4571d937bab4c7eb", null ],
    [ "initialize", "classCustomLinearMobility.html#aab0ea271c37a1073f8b3d911dfe69765", null ],
    [ "move", "classCustomLinearMobility.html#acf9bc9ca320e8a065877a8bc61d7fc91", null ],
    [ "hasMaxSpeed", "classCustomLinearMobility.html#a279ee60fec621ffb1ef3e93c6b71e83c", null ],
    [ "maxSpeed", "classCustomLinearMobility.html#a4386de7f7358c394f995dd5f73f39ea2", null ]
];