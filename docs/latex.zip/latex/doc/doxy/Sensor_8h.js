var Sensor_8h =
[
    [ "Sensor", "classSensor.html", "classSensor" ],
    [ "Define_Module", "Sensor_8h.html#a37f9d89cfdc64344631675232f9b89cc", null ]
];