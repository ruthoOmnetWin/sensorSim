var hierarchy =
[
    [ "BaseWorldUtility", null, [
      [ "CustomWorldUtility", "classCustomWorldUtility.html", null ]
    ] ],
    [ "cObject", "/home/rutho/BA/omnetpp-4.5//doc/api/classcObject.html", [
      [ "cNamedObject", "/home/rutho/BA/omnetpp-4.5//doc/api/classcNamedObject.html", [
        [ "cOwnedObject", "/home/rutho/BA/omnetpp-4.5//doc/api/classcOwnedObject.html", [
          [ "cMessage", "/home/rutho/BA/omnetpp-4.5//doc/api/classcMessage.html", [
            [ "ExtendedMessage", "classExtendedMessage.html", null ]
          ] ],
          [ "cNoncopyableOwnedObject", "/home/rutho/BA/omnetpp-4.5//doc/api/classcNoncopyableOwnedObject.html", [
            [ "cComponentType", "/home/rutho/BA/omnetpp-4.5//doc/api/classcComponentType.html", [
              [ "cModuleType", "/home/rutho/BA/omnetpp-4.5//doc/api/classcModuleType.html", [
                [ "NodeType", "classNodeType.html", null ]
              ] ]
            ] ],
            [ "cDefaultList", "/home/rutho/BA/omnetpp-4.5//doc/api/classcDefaultList.html", [
              [ "cComponent", "/home/rutho/BA/omnetpp-4.5//doc/api/classcComponent.html", [
                [ "cModule", "/home/rutho/BA/omnetpp-4.5//doc/api/classcModule.html", [
                  [ "cSimpleModule", "/home/rutho/BA/omnetpp-4.5//doc/api/classcSimpleModule.html", [
                    [ "Sensor", "classSensor.html", [
                      [ "MyWirelessNode", "classMyWirelessNode.html", null ]
                    ] ]
                  ] ]
                ] ]
              ] ]
            ] ]
          ] ]
        ] ],
        [ "SimpleCoord", "classSimpleCoord.html", null ],
        [ "SimpleSensorData", "classSimpleSensorData.html", null ],
        [ "SimpleSensorType", "classSimpleSensorType.html", null ]
      ] ]
    ] ],
    [ "LinearMobility", null, [
      [ "CustomLinearMobility", "classCustomLinearMobility.html", null ]
    ] ],
    [ "noncopyable", "/home/rutho/BA/omnetpp-4.5//doc/api/classnoncopyable.html", [
      [ "cNoncopyableOwnedObject", "/home/rutho/BA/omnetpp-4.5//doc/api/classcNoncopyableOwnedObject.html", null ]
    ] ],
    [ "SensorType", "structSensorType.html", null ],
    [ "StatisticsInterface", "classStatisticsInterface.html", [
      [ "CustomWorldUtility", "classCustomWorldUtility.html", null ],
      [ "MyWirelessNode", "classMyWirelessNode.html", null ]
    ] ]
];