var classSimpleCoord =
[
    [ "SimpleCoord", "classSimpleCoord.html#a37ab4d0084af1172c2575cffaa36fdb5", null ],
    [ "~SimpleCoord", "classSimpleCoord.html#af663b9f80277911f125793353554e802", null ],
    [ "SimpleCoord", "classSimpleCoord.html#ab3da4ddd61e6b668c9c1938eb5e8fde9", null ],
    [ "dup", "classSimpleCoord.html#a434e2e3cd9788663e2f93267b2280c38", null ],
    [ "x", "classSimpleCoord.html#ad8d88f139da61a0bc30fee4518c01788", null ],
    [ "y", "classSimpleCoord.html#a10cd9244f71d5694962ef6dcfa419127", null ],
    [ "z", "classSimpleCoord.html#a2d02de11069b84ba78781eb5793f1df6", null ]
];