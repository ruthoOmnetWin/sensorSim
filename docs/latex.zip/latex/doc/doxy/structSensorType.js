var structSensorType =
[
    [ "humidity", "structSensorType.html#ab597eb8b3bf9f572ed1f0b74c089289b", null ],
    [ "light", "structSensorType.html#a79dd638b982c097c9f09c5b0de270e1e", null ],
    [ "pressure", "structSensorType.html#a244163d8d6d2dc5909c3bfff81946359", null ],
    [ "temperature", "structSensorType.html#a101ab24e3f8976cac261b0d852943a56", null ]
];